<?php
    class Booked
    {
        private $db=null;
        private static $settingsList = null;
		function __construct()
        {
			$this->db = Database::GetDatabaseConnection();
		}
        
        function GetBookedList($pageLimit, $setLimit)
        {
            $query = "SELECT * FROM booked  LIMIT ".$pageLimit." , ".$setLimit;
            return $this->db->GetManyRow($query);
        }  
        function GetList()
        {
            $query = "SELECT dates from booked";
            return $this->db->GetRow($query);
        }    
        function GetBookedDays($year,$month)
        {
            $sql = "SELECT dates FROM booked WHERE YEAR(dates)=? AND MONTH(dates) = ?";
            $parameter = array($year,$month);
            $types = array("s","s");
            return $this->db->GetRowList($sql, $parameter, $types);
        }
        function GetBookedHistory()
        {
            $sql = "SELECT COUNT(*) AS numbers FROM booked";
            return $this->db->GetManyRow($sql);
        }
        function GetBookedNumber()
        {
            $sql = "SELECT COUNT(*) AS totalCount FROM booked";
            return $this->db->GetManyRow($sql);
        }
        
        function CheckBooked($dates)
        {
            $sql = "SELECT * FROM booked WHERE dates= ?";
            $parameter = array($dates);
            $types = array("s");
            return $this->db->GetRow($sql, $parameter, $types);
        }
        function GetOrderDetail($start,$end)
        {
            //echo "Email: ".$email." ".$password;
            $query = "SELECT * FROM booked WHERE booked_id BETWEEN $end AND $start ";
            $parameters = array();
            $types = array();
            return $this->db->GetManyRow($query);
        }
        function AcceptRequest($userId,$dates)
        {
            $query = "INSERT INTO booked(user_id, dates) VALUES(?,?)";
            $parameters = array($userId,$dates);
            $types = array("i","s");
            return $this->db->Insert($query,$parameters,$types);
        }
        
        
    }
?>